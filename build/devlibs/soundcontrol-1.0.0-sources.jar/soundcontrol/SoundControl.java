package soundcontrol;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class SoundControl implements ClientModInitializer {
    public static KeyBinding openScreenKey;

    @Override
    public void onInitializeClient() {
        SoundConfig.load();

        openScreenKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.soundcontrol.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_V,
                "category.soundcontrol.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openScreenKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new SoundControlScreen());
                }
            }
        });
    }
}