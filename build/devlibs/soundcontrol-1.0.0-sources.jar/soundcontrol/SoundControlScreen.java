package soundcontrol;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class SoundControlScreen extends Screen {
    private TextFieldWidget searchBox;
    private SoundListWidget soundList;
    private SoundCategory currentCategory = SoundCategory.ALL;
    private boolean isAdvanced = false;

    public SoundControlScreen() {
        super(Text.literal("Sound Control"));
    }

    @Override
    protected void init() {
        this.searchBox = new TextFieldWidget(this.textRenderer, this.width / 2 - 110, 22, 220, 20, Text.literal(""));
        this.searchBox.setChangedListener(this::onSearch);
        this.addSelectableChild(this.searchBox);

        int buttonWidth = 60;
        int startX = this.width / 2 - (buttonWidth * 4 + 15) / 2;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("All"), b -> setCategory(SoundCategory.ALL)).dimensions(startX, 46, buttonWidth, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Mobs"), b -> setCategory(SoundCategory.MOBS)).dimensions(startX + buttonWidth + 5, 46, buttonWidth, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Blocks"), b -> setCategory(SoundCategory.BLOCKS)).dimensions(startX + (buttonWidth + 5) * 2, 46, buttonWidth, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Mods"), b -> setCategory(SoundCategory.MODS)).dimensions(startX + (buttonWidth + 5) * 3, 46, buttonWidth, 20).build());

        this.soundList = new SoundListWidget(this.client, this.width, this.height - 116, 72, 25);
        this.addSelectableChild(this.soundList);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Mode: Basic"), button -> {
            this.isAdvanced = !this.isAdvanced;
            button.setMessage(Text.literal("Mode: " + (this.isAdvanced ? "Advanced" : "Basic")));
            this.soundList.loadEntries(this.isAdvanced);
            this.soundList.filter(this.searchBox.getText(), this.currentCategory);
        }).dimensions(this.width / 2 - 160, this.height - 28, 100, 20).build());

        this.addDrawableChild(ButtonWidget.builder(ScreenTexts.DONE, button -> this.close())
                .dimensions(this.width / 2 - 50, this.height - 28, 100, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Reset All"), button -> {
            SoundConfig.SOUNDS.clear();
            SoundConfig.save();
            this.soundList.loadEntries(this.isAdvanced);
            this.soundList.filter(this.searchBox.getText(), this.currentCategory);
        }).dimensions(this.width / 2 + 60, this.height - 28, 100, 20).build());

        this.setInitialFocus(this.searchBox);
        this.soundList.filter(this.searchBox.getText(), this.currentCategory);
    }

    private void setCategory(SoundCategory category) {
        this.currentCategory = category;
        this.soundList.filter(this.searchBox.getText(), this.currentCategory);
    }

    private void onSearch(String query) {
        if (this.soundList != null) {
            this.soundList.filter(query, this.currentCategory);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        this.soundList.render(context, mouseX, mouseY, delta);
        this.searchBox.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 8, 0xFFFFFF);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE && this.shouldCloseOnEsc()) {
            this.close();
            return true;
        }
        if (this.searchBox.keyPressed(keyCode, scanCode, modifiers) || this.searchBox.isActive()) {
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}