package soundcontrol;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ElementListWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SoundListWidget extends ElementListWidget<SoundListWidget.SoundEntry> {
    private final List<SoundEntry> allEntries = new ArrayList<>();

    public SoundListWidget(MinecraftClient client, int width, int height, int y, int itemHeight) {
        super(client, width, height, y, itemHeight);
        this.loadEntries(false);
    }

    public void loadEntries(boolean isAdvanced) {
        this.allEntries.clear();

        if (isAdvanced) {
            List<String> rawIds = new ArrayList<>();
            for (Identifier id : Registries.SOUND_EVENT.getIds()) {
                rawIds.add(id.toString());
            }
            Collections.sort(rawIds);
            for (String id : rawIds) {
                this.allEntries.add(new SoundEntry(id));
            }
        } else {
            Set<String> uniqueGroups = new HashSet<>();
            for (Identifier id : Registries.SOUND_EVENT.getIds()) {
                uniqueGroups.add(SoundConfig.getSoundGroup(id.toString()));
            }

            List<String> sortedGroups = new ArrayList<>(uniqueGroups);
            Collections.sort(sortedGroups);

            this.allEntries.add(new SoundEntry("#global:break"));
            this.allEntries.add(new SoundEntry("#global:place"));
            this.allEntries.add(new SoundEntry("#global:step"));
            this.allEntries.add(new SoundEntry("#global:hit"));
            this.allEntries.add(new SoundEntry("#global:hostile_hurt"));
            this.allEntries.add(new SoundEntry("#global:passive_hurt"));

            for (String group : sortedGroups) {
                this.allEntries.add(new SoundEntry(group));
            }
        }
    }

    @Override
    public int getRowWidth() {
        return 380;
    }

    @Override
    protected int getScrollbarX() {
        return this.width / 2 + 195;
    }

    public void filter(String query, SoundCategory category) {
        this.clearEntries();
        String lowerQuery = query.toLowerCase();
        for (SoundEntry entry : this.allEntries) {
            boolean matchCategory = false;

            if (category == SoundCategory.ALL) {
                matchCategory = true;
            } else if (category == SoundCategory.MOBS) {
                matchCategory = entry.soundId.startsWith("minecraft:entity.") || entry.soundId.contains("_hurt");
            } else if (category == SoundCategory.BLOCKS) {
                matchCategory = entry.soundId.startsWith("minecraft:block.");
            } else if (category == SoundCategory.MODS) {
                matchCategory = !entry.soundId.startsWith("minecraft:") && !entry.soundId.startsWith("#global:");
            }

            if (matchCategory && entry.soundId.toLowerCase().contains(lowerQuery)) {
                this.addEntry(entry);
            }
        }
        this.setScrollAmount(0);
    }

    public static class SoundEntry extends ElementListWidget.Entry<SoundEntry> {
        final String soundId;
        private final ButtonWidget muteButton;
        private final SliderWidget volumeSlider;

        public SoundEntry(String soundId) {
            this.soundId = soundId;

            boolean initialMuted = false;
            float initialVolume = 1.0f;

            if (SoundConfig.SOUNDS.containsKey(soundId)) {
                initialMuted = SoundConfig.SOUNDS.get(soundId).muted;
                initialVolume = SoundConfig.SOUNDS.get(soundId).volume;
            }

            this.muteButton = ButtonWidget.builder(Text.literal(initialMuted ? "Unmute" : "Mute"), button -> {
                SoundConfig.SoundSettings s = SoundConfig.SOUNDS.computeIfAbsent(this.soundId, k -> new SoundConfig.SoundSettings());
                s.muted = !s.muted;
                button.setMessage(Text.literal(s.muted ? "Unmute" : "Mute"));
                SoundConfig.save();
            }).dimensions(0, 0, 50, 20).build();

            this.volumeSlider = new SliderWidget(0, 0, 100, 20, Text.literal(String.format("Volume: %d%%", (int)(initialVolume * 100))), initialVolume / 2.0f) {
                @Override
                protected void updateMessage() {
                    this.setMessage(Text.literal(String.format("Volume: %d%%", (int)(this.value * 200))));
                }

                @Override
                protected void applyValue() {
                    SoundConfig.SoundSettings s = SoundConfig.SOUNDS.computeIfAbsent(soundId, k -> new SoundConfig.SoundSettings());
                    s.volume = (float) (this.value * 2.0f);
                    SoundConfig.save();
                }
            };
        }

        @Override
        public void render(DrawContext context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
            String displayId = this.soundId;
            if (displayId.equals("#global:break")) displayId = "ALL BREAKING SOUNDS";
            if (displayId.equals("#global:place")) displayId = "ALL PLACING SOUNDS";
            if (displayId.equals("#global:step")) displayId = "ALL FOOTSTEP SOUNDS";
            if (displayId.equals("#global:hit")) displayId = "ALL HIT SOUNDS";
            if (displayId.equals("#global:hostile_hurt")) displayId = "ALL HOSTILE MOB HURT SOUNDS";
            if (displayId.equals("#global:passive_hurt")) displayId = "ALL PASSIVE MOB HURT SOUNDS";

            String trimmedText = MinecraftClient.getInstance().textRenderer.trimToWidth(displayId, entryWidth - 165);
            int color = this.soundId.startsWith("#global:") ? 0xFFAA00 : 0xFFFFFF;
            context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, trimmedText, x + 5, y + 6, color);

            this.muteButton.setX(x + entryWidth - 160);
            this.muteButton.setY(y);
            this.muteButton.render(context, mouseX, mouseY, tickDelta);

            this.volumeSlider.setX(x + entryWidth - 105);
            this.volumeSlider.setY(y);
            this.volumeSlider.render(context, mouseX, mouseY, tickDelta);
        }

        @Override
        public List<? extends net.minecraft.client.gui.Element> children() {
            return List.of(this.muteButton, this.volumeSlider);
        }

        @Override
        public List<? extends net.minecraft.client.gui.Selectable> selectableChildren() {
            return List.of(this.muteButton, this.volumeSlider);
        }
    }
}