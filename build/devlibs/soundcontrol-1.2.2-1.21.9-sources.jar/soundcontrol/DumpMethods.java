package soundcontrol;

import net.minecraft.client.gui.ParentElement;
import net.minecraft.client.gui.DrawContext;
import java.lang.reflect.Method;

public class DumpMethods {
    public static void doDump() {
        System.out.println("--- PARENT ELEMENT METHODS ---");
        for(Method m : ParentElement.class.getMethods()) {
            if(m.getName().startsWith("mouse")) {
                System.out.println(m.toString());
            }
        }
        System.out.println("--- DRAW CONTEXT METHODS ---");
        for(Method m : DrawContext.class.getMethods()) {
            if(m.getName().toLowerCase().contains("border") || m.getName().toLowerCase().contains("outline")) {
                System.out.println(m.toString());
            }
        }
    }
}
