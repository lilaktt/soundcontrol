/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.item;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import net.fabricmc.fabric.api.item.v1.FabricItem;
import net.minecraft.class_10162;
import net.minecraft.class_1792;
import net.minecraft.class_2960;

@Mixin(class_1792.class_1793.class)
public class ItemSettingsMixin implements FabricItem.Settings {
	@Shadow
	private class_10162<class_1792, class_2960> modelId;

	@Override
	public class_1792.class_1793 modelId(class_2960 modelId) {
		this.modelId = class_10162.fixed(modelId);
		return FabricItem.Settings.super.modelId(modelId);
	}
}
