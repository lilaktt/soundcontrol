package soundcontrol;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import org.lwjgl.glfw.GLFW;

public class SoundControlScreen extends class_437 {
    private class_342 searchBox;
    private SoundListWidget soundList;
    private ModListWidget modList;
    private SoundCategory currentCategory = SoundCategory.ALL;
    private int viewMode = 0;
    private String selectedMod = "";
    private int filterMode = 0;

    public SoundControlScreen() {
        super(class_2561.method_43471("text.soundcontrol.title"));
    }

    private class_2561 getFilterText() {
        if (this.filterMode == 1) return class_2561.method_43471("text.soundcontrol.filter.edited");
        if (this.filterMode == 2) return class_2561.method_43471("text.soundcontrol.filter.favorites");
        return class_2561.method_43471("text.soundcontrol.filter.all");
    }

    @Override
    protected void method_25426() {
        this.searchBox = new class_342(this.field_22793, this.field_22789 / 2 - 140, 22, 180, 20, class_2561.method_43470(""));
        this.searchBox.method_1863(this::onSearch);
        this.method_25429(this.searchBox);

        this.method_37063(class_4185.method_46430(getFilterText(), button -> {
            this.filterMode = (this.filterMode + 1) % 3;
            button.method_25355(getFilterText());
            this.soundList.filter(this.searchBox.method_1882(), this.currentCategory, this.selectedMod, this.viewMode, this.filterMode);
        }).method_46434(this.field_22789 / 2 + 50, 22, 100, 20).method_46431());

        int buttonWidth = 60;
        int startX = this.field_22789 / 2 - (buttonWidth * 3 + 10) / 2;

        this.method_37063(class_4185.method_46430(class_2561.method_43471("text.soundcontrol.category.all"), b -> setCategory(SoundCategory.ALL)).method_46434(startX, 46, buttonWidth, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43471("text.soundcontrol.category.mobs"), b -> setCategory(SoundCategory.MOBS)).method_46434(startX + buttonWidth + 5, 46, buttonWidth, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43471("text.soundcontrol.category.blocks"), b -> setCategory(SoundCategory.BLOCKS)).method_46434(startX + (buttonWidth + 5) * 2, 46, buttonWidth, 20).method_46431());

        this.soundList = new SoundListWidget(this.field_22787, this.field_22789, this.field_22790 - 116, 72, 25);
        this.method_25429(this.soundList);

        this.modList = new ModListWidget(this.field_22787, 120, this.field_22790 - 116, 72, 15, this);
        this.modList.method_46421(this.field_22789 - 120);
        this.method_25429(this.modList);

        if (!this.modList.method_25396().isEmpty()) {
            this.selectedMod = ((ModListWidget.ModEntry) this.modList.method_25396().get(0)).getModId();
        }

        this.method_37063(class_4185.method_46430(class_2561.method_43471("text.soundcontrol.mode.basic"), button -> {
            this.viewMode = (this.viewMode + 1) % 3;
            String modeKey = this.viewMode == 0 ? "basic" : (this.viewMode == 1 ? "advanced" : "mods");
            button.method_25355(class_2561.method_43471("text.soundcontrol.mode." + modeKey));
            this.soundList.loadEntries(this.viewMode);
            this.soundList.filter(this.searchBox.method_1882(), this.currentCategory, this.selectedMod, this.viewMode, this.filterMode);
        }).method_46434(this.field_22789 / 2 - 160, this.field_22790 - 28, 100, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_5244.field_24334, button -> this.method_25419())
                .method_46434(this.field_22789 / 2 - 50, this.field_22790 - 28, 100, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43471("text.soundcontrol.button.reset"), button -> {
            SoundConfig.resetSettings();
            this.soundList.loadEntries(this.viewMode);
            this.soundList.filter(this.searchBox.method_1882(), this.currentCategory, this.selectedMod, this.viewMode, this.filterMode);
        }).method_46434(this.field_22789 / 2 + 60, this.field_22790 - 28, 100, 20).method_46431());

        this.method_48265(this.searchBox);
        this.soundList.loadEntries(this.viewMode);
        this.soundList.filter(this.searchBox.method_1882(), this.currentCategory, this.selectedMod, this.viewMode, this.filterMode);
    }

    private void setCategory(SoundCategory category) {
        this.currentCategory = category;
        this.soundList.filter(this.searchBox.method_1882(), this.currentCategory, this.selectedMod, this.viewMode, this.filterMode);
    }

    public void setSelectedMod(String modId) {
        this.selectedMod = modId;
        this.soundList.filter(this.searchBox.method_1882(), this.currentCategory, this.selectedMod, this.viewMode, this.filterMode);
    }

    public String getSelectedMod() {
        return this.selectedMod;
    }

    private void onSearch(String query) {
        if (this.soundList != null) {
            this.soundList.filter(query, this.currentCategory, this.selectedMod, this.viewMode, this.filterMode);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        this.soundList.method_25394(context, mouseX, mouseY, delta);

        if (this.viewMode == 2) {
            this.modList.method_25394(context, mouseX, mouseY, delta);
        }

        this.searchBox.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 8, 0xFFFFFFFF);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE && this.method_25422()) {
            this.method_25419();
            return true;
        }
        if (this.searchBox.method_25404(keyCode, scanCode, modifiers) || this.searchBox.method_20315()) {
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}