package soundcontrol;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1109;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_7919;

public class SoundListWidget extends class_4265<SoundListWidget.SoundEntry> {
    private final List<SoundEntry> allEntries = new ArrayList<>();

    public SoundListWidget(class_310 client, int width, int height, int y, int itemHeight) {
        super(client, width, height, y, itemHeight);
    }

    public void loadEntries(int viewMode) {
        this.allEntries.clear();
        Collection<class_2960> soundIds = class_310.method_1551().method_1483().method_4864();

        if (viewMode == 1 || viewMode == 2) {
            List<String> rawIds = new ArrayList<>();
            for (class_2960 id : soundIds) {
                rawIds.add(id.toString());
            }
            Collections.sort(rawIds);
            for (String id : rawIds) {
                this.allEntries.add(new SoundEntry(id, viewMode, this.method_25322()));
            }
        } else {
            Set<String> uniqueGroups = new HashSet<>();
            for (class_2960 id : soundIds) {
                if (id.method_12836().equals("minecraft")) {
                    uniqueGroups.add(SoundConfig.getSoundGroup(id.toString()));
                }
            }

            List<String> sortedGroups = new ArrayList<>(uniqueGroups);
            Collections.sort(sortedGroups);

            this.allEntries.add(new SoundEntry("#global:break", viewMode, this.method_25322()));
            this.allEntries.add(new SoundEntry("#global:place", viewMode, this.method_25322()));
            this.allEntries.add(new SoundEntry("#global:step", viewMode, this.method_25322()));
            this.allEntries.add(new SoundEntry("#global:hit", viewMode, this.method_25322()));
            this.allEntries.add(new SoundEntry("#global:hostile_hurt", viewMode, this.method_25322()));
            this.allEntries.add(new SoundEntry("#global:passive_hurt", viewMode, this.method_25322()));
            this.allEntries.add(new SoundEntry("#global:hostile_ambient", viewMode, this.method_25322()));
            this.allEntries.add(new SoundEntry("#global:passive_ambient", viewMode, this.method_25322()));

            for (String group : sortedGroups) {
                this.allEntries.add(new SoundEntry(group, viewMode, this.method_25322()));
            }
        }
    }

    @Override
    public int method_25322() {
        return 380;
    }

    @Override
    protected int method_65507() {
        return this.field_22758 / 2 + 195;
    }

    public void filter(String query, SoundCategory category, String selectedMod, int viewMode, int filterMode) {
        this.method_25339();
        String lowerQuery = query.toLowerCase();
        for (SoundEntry entry : this.allEntries) {

            if (filterMode == 1 && !SoundConfig.SOUNDS.containsKey(entry.soundId)) {
                continue;
            }

            if (filterMode == 2) {
                if (!SoundConfig.SOUNDS.containsKey(entry.soundId) || !SoundConfig.SOUNDS.get(entry.soundId).favorite) {
                    continue;
                }
            }

            boolean matchCategory = false;

            if (viewMode == 2) {
                if (selectedMod != null && !selectedMod.isEmpty()) {
                    if (selectedMod.equals("all")) {
                        matchCategory = !entry.soundId.startsWith("minecraft:") && !entry.soundId.startsWith("#global:");
                    } else {
                        matchCategory = entry.soundId.startsWith(selectedMod + ":");
                    }
                } else {
                    matchCategory = false;
                }
            } else {
                if (category == SoundCategory.ALL) {
                    matchCategory = true;
                } else if (category == SoundCategory.MOBS) {
                    matchCategory = entry.soundId.startsWith("minecraft:entity.") || entry.soundId.contains("_hurt") || entry.soundId.contains("_ambient");
                } else if (category == SoundCategory.BLOCKS) {
                    matchCategory = entry.soundId.startsWith("minecraft:block.");
                }
            }

            if (matchCategory && entry.soundId.toLowerCase().contains(lowerQuery)) {
                this.method_25321(entry);
            }
        }
    }

    public static class SoundEntry extends class_4265.class_4266<SoundEntry> {
        final String soundId;
        private final class_4185 playButton;
        private final class_4185 muteButton;
        private final class_357 volumeSlider;
        private final class_4185 favoriteButton;
        private class_1109 playingInstance;
        private final int entryWidth;

        public SoundEntry(String soundId, int viewMode, int entryWidth) {
            this.soundId = soundId;
            this.entryWidth = entryWidth;

            boolean initialMuted = false;
            float initialVolume = 1.0f;
            boolean initialFavorite = false;

            if (SoundConfig.SOUNDS.containsKey(soundId)) {
                initialMuted = SoundConfig.SOUNDS.get(soundId).muted;
                initialVolume = SoundConfig.SOUNDS.get(soundId).volume;
                initialFavorite = SoundConfig.SOUNDS.get(soundId).favorite;
            }

            boolean isBasicMode = (viewMode == 0);
            class_2960 parsedId = class_2960.method_12829(this.soundId);
            boolean isPlayable = !isBasicMode && parsedId != null;

            class_4185.class_7840 playBuilder = class_4185.method_46430(class_2561.method_43470("▶"), button -> {
                class_310 client = class_310.method_1551();
                if (this.playingInstance != null && client.method_1483().method_4877(this.playingInstance)) {
                    client.method_1483().method_4870(this.playingInstance);
                    this.playingInstance = null;
                } else if (isPlayable) {
                    class_3414 event = class_3414.method_47908(parsedId);
                    this.playingInstance = class_1109.method_4757(event, 1.0F, 1.0F);
                    client.method_1483().method_4873(this.playingInstance);
                }
            }).method_46434(0, 0, 20, 20);

            if (isBasicMode) {
                playBuilder.method_46436(class_7919.method_47407(class_2561.method_43471("text.soundcontrol.tooltip.advanced_only")));
            }

            this.playButton = playBuilder.method_46431();
            this.playButton.field_22763 = isPlayable;

            this.muteButton = class_4185.method_46430(class_2561.method_43471(initialMuted ? "text.soundcontrol.button.unmute" : "text.soundcontrol.button.mute"), button -> {
                SoundConfig.SoundSettings s = SoundConfig.SOUNDS.computeIfAbsent(this.soundId, k -> new SoundConfig.SoundSettings());
                s.muted = !s.muted;
                button.method_25355(class_2561.method_43471(s.muted ? "text.soundcontrol.button.unmute" : "text.soundcontrol.button.mute"));
                SoundConfig.save();
            }).method_46434(0, 0, 50, 20).method_46431();

            this.volumeSlider = new class_357(0, 0, 100, 20, class_2561.method_43469("text.soundcontrol.slider.volume", (int)(initialVolume * 100)), initialVolume / 2.0f) {
                @Override
                protected void method_25346() {
                    this.method_25355(class_2561.method_43469("text.soundcontrol.slider.volume", (int)(this.field_22753 * 200)));
                }

                @Override
                protected void method_25344() {
                    SoundConfig.SoundSettings s = SoundConfig.SOUNDS.computeIfAbsent(soundId, k -> new SoundConfig.SoundSettings());
                    s.volume = (float) (this.field_22753 * 2.0f);
                    SoundConfig.save();
                }
            };

            this.favoriteButton = class_4185.method_46430(class_2561.method_43470(initialFavorite ? "★" : "☆"), button -> {
                SoundConfig.SoundSettings s = SoundConfig.SOUNDS.computeIfAbsent(this.soundId, k -> new SoundConfig.SoundSettings());
                s.favorite = !s.favorite;
                button.method_25355(class_2561.method_43470(s.favorite ? "★" : "☆"));
                SoundConfig.save();
            }).method_46434(0, 0, 20, 20).method_46431();
        }

        public void method_25343(class_332 context, int mouseX, int mouseY, boolean hovered, float tickDelta) {
            // ТУТ СПРАВЖНІ КООРДИНАТИ!
            int x = this.method_46426();
            int y = this.method_46427();

            boolean isPlaying = this.playingInstance != null && class_310.method_1551().method_1483().method_4877(this.playingInstance);
            this.playButton.method_25355(class_2561.method_43470(isPlaying ? "■" : "▶"));

            class_2561 displayIdText = class_2561.method_43470(this.soundId);

            if (this.soundId.equals("#global:break")) displayIdText = class_2561.method_43471("text.soundcontrol.global.break");
            if (this.soundId.equals("#global:place")) displayIdText = class_2561.method_43471("text.soundcontrol.global.place");
            if (this.soundId.equals("#global:step")) displayIdText = class_2561.method_43471("text.soundcontrol.global.step");
            if (this.soundId.equals("#global:hit")) displayIdText = class_2561.method_43471("text.soundcontrol.global.hit");
            if (this.soundId.equals("#global:hostile_hurt")) displayIdText = class_2561.method_43471("text.soundcontrol.global.hostile_hurt");
            if (this.soundId.equals("#global:passive_hurt")) displayIdText = class_2561.method_43471("text.soundcontrol.global.passive_hurt");
            if (this.soundId.equals("#global:hostile_ambient")) displayIdText = class_2561.method_43471("text.soundcontrol.global.hostile_ambient");
            if (this.soundId.equals("#global:passive_ambient")) displayIdText = class_2561.method_43471("text.soundcontrol.global.passive_ambient");

            String textStr = displayIdText.getString();
            String trimmedText = class_310.method_1551().field_1772.method_27523(textStr, this.entryWidth - 215);
            int color = this.soundId.startsWith("#global:") ? 0xFFFFAA00 : 0xFFFFFFFF;

            context.method_25303(class_310.method_1551().field_1772, trimmedText, x + 5, y + 6, color);

            this.playButton.method_46421(x + this.entryWidth - 210);
            this.playButton.method_46419(y);
            this.playButton.method_25394(context, mouseX, mouseY, tickDelta);

            this.muteButton.method_46421(x + this.entryWidth - 185);
            this.muteButton.method_46419(y);
            this.muteButton.method_25394(context, mouseX, mouseY, tickDelta);

            this.volumeSlider.method_46421(x + this.entryWidth - 130);
            this.volumeSlider.method_46419(y);
            this.volumeSlider.method_25394(context, mouseX, mouseY, tickDelta);

            this.favoriteButton.method_46421(x + this.entryWidth - 25);
            this.favoriteButton.method_46419(y);
            this.favoriteButton.method_25394(context, mouseX, mouseY, tickDelta);
        }

        public List<? extends net.minecraft.class_364> method_25396() {
            return List.of(this.playButton, this.muteButton, this.volumeSlider, this.favoriteButton);
        }

        public List<? extends net.minecraft.class_6379> method_37025() {
            return List.of(this.playButton, this.muteButton, this.volumeSlider, this.favoriteButton);
        }
    }
}