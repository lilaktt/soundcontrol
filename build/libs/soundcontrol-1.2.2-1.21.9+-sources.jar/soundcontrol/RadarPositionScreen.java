package soundcontrol;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class RadarPositionScreen extends class_437 {
    private final class_437 parent;
    private int radarX;
    private int radarY;
    private boolean dragging = false;
    private double dragStartX;
    private double dragStartY;

    public RadarPositionScreen(class_437 parent) {
        super(class_2561.method_43471("text.soundcontrol.radar_position.title"));
        this.parent = parent;
        this.radarX = SoundConfig.getRadarX();
        this.radarY = SoundConfig.getRadarY();
        if (this.radarY == -1) {
            this.radarY = 100;
        }
    }

    @Override
    protected void method_25426() {
        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.save"), button -> {
            SoundConfig.setRadarPos(this.radarX, this.radarY);
            SoundConfig.save();
            this.field_22787.method_1507(this.parent);
        }).method_46434(this.field_22789 / 2 - 105, this.field_22790 - 40, 100, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"), button -> {
            this.field_22787.method_1507(this.parent);
        }).method_46434(this.field_22789 / 2 + 5, this.field_22790 - 40, 100, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        boolean isLeftMouseDown = org.lwjgl.glfw.GLFW.glfwGetMouseButton(this.field_22787.method_22683().method_4490(), org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_LEFT) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
        
        if (isLeftMouseDown) {
            if (!this.dragging) {
                if (mouseX >= this.radarX - 5 && mouseX <= this.radarX + 115 && mouseY >= this.radarY - 5 && mouseY <= this.radarY + 35) {
                    this.dragging = true;
                    this.dragStartX = mouseX - this.radarX;
                    this.dragStartY = mouseY - this.radarY;
                }
            } else {
                this.radarX = (int) (mouseX - this.dragStartX);
                this.radarY = (int) (mouseY - this.dragStartY);
                this.radarX = Math.max(0, Math.min(this.radarX, this.field_22789 - 100));
                this.radarY = Math.max(0, Math.min(this.radarY, this.field_22790 - 50));
            }
        } else {
            this.dragging = false;
        }

        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFFFF);
        context.method_27534(this.field_22793, class_2561.method_43471("text.soundcontrol.radar_position.help"), this.field_22789 / 2, 35, 0xFFAAAAAA);

        int previewX = this.radarX;
        int previewY = this.radarY;

        context.method_25303(this.field_22793, "» [Preview Sound 1]", previewX, previewY, 0xFFFFFFFF);
        context.method_25303(this.field_22793, "» [Preview Sound 2]", previewX, previewY + 10, 0xFFFFFFFF);
        context.method_25303(this.field_22793, "» [Preview Sound 3]", previewX, previewY + 20, 0xFFFFFFFF);

        context.method_25294(previewX - 2, previewY - 2, previewX + 118, previewY - 1, 0x88FFFFFF);
        context.method_25294(previewX - 2, previewY + 33, previewX + 118, previewY + 34, 0x88FFFFFF);
        context.method_25294(previewX - 2, previewY - 1, previewX - 1, previewY + 33, 0x88FFFFFF);
        context.method_25294(previewX + 117, previewY - 1, previewX + 118, previewY + 33, 0x88FFFFFF);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
