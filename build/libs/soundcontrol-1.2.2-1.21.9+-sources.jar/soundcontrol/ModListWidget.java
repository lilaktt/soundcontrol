package soundcontrol;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_4265;

public class ModListWidget extends class_4265<ModListWidget.ModEntry> {
    private final SoundControlScreen parent;

    public ModListWidget(class_310 client, int width, int height, int y, int itemHeight, SoundControlScreen parent) {
        super(client, width, height, y, itemHeight);
        this.parent = parent;

        this.method_25321(new ModEntry("all", this));

        Set<String> namespaces = new HashSet<>();
        Collection<class_2960> soundIds = client.method_1483().method_4864();
        for (class_2960 id : soundIds) {
            String namespace = id.method_12836();
            if (!namespace.equals("minecraft")) {
                namespaces.add(namespace);
            }
        }

        List<String> sortedNamespaces = new ArrayList<>(namespaces);
        Collections.sort(sortedNamespaces);

        for (String namespace : sortedNamespaces) {
            this.method_25321(new ModEntry(namespace, this));
        }
    }

    @Override
    public int method_25322() {
        return 100;
    }

    @Override
    protected int method_65507() {
        return this.method_46426() + this.field_22758 - 6;
    }

    public void selectMod(String modId) {
        this.parent.setSelectedMod(modId);
    }

    public class ModEntry extends class_4265.class_4266<ModEntry> {
        private final String modId;
        private final ModListWidget parentList;
        private final class_4185 button;

        public ModEntry(String modId, ModListWidget parentList) {
            this.modId = modId;
            this.parentList = parentList;

            String displayText = this.modId.equals("all") ? class_2561.method_43471("text.soundcontrol.modlist.all").getString() : this.modId;

            this.button = class_4185.method_46430(class_2561.method_43470(displayText), b -> {
                this.parentList.selectMod(this.modId);
            }).method_46434(0, 0, 100, 15).method_46431();
        }

        public String getModId() {
            return this.modId;
        }

        public void method_25343(class_332 context, int mouseX, int mouseY, boolean hovered, float tickDelta) {
            int x = this.parentList.method_25342();
            int y = this.method_46427();

            this.button.method_46421(x);
            this.button.method_46419(y);

            boolean isSelected = parentList.parent.getSelectedMod().equals(this.modId);
            String prefix = isSelected ? "▶ " : "";
            String displayText = this.modId.equals("all") ? class_2561.method_43471("text.soundcontrol.modlist.all").getString() : this.modId;
            this.button.method_25355(class_2561.method_43470(prefix + displayText));

            this.button.method_25394(context, mouseX, mouseY, tickDelta);
        }

        public List<? extends net.minecraft.class_364> method_25396() {
            return List.of(this.button);
        }

        public List<? extends net.minecraft.class_6379> method_37025() {
            return List.of(this.button);
        }
    }
}