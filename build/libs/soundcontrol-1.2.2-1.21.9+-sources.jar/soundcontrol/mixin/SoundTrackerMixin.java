package soundcontrol.mixin;

import net.minecraft.class_1113;
import net.minecraft.class_1144;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import soundcontrol.SoundTracker;

@Mixin(class_1144.class)
public class SoundTrackerMixin {
    @Inject(method = "play", at = @At("HEAD"))
    private void onPlaySound(class_1113 sound, CallbackInfoReturnable<?> cir) {
        if (sound != null && sound.method_4775() != null) {
            SoundTracker.recordSound(sound.method_4775().toString());
        }
    }
}