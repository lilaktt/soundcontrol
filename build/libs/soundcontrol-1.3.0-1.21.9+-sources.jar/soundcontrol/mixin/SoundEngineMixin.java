package soundcontrol.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_3419;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import soundcontrol.SoundConfig;

@Mixin(class_1140.class)
public class SoundEngineMixin {
    @WrapOperation(
            method = "play",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/sound/SoundSystem;getAdjustedVolume(FLnet/minecraft/sound/SoundCategory;)F")
    )
    private float amplifyVolume(class_1140 instance, float volume, class_3419 category, Operation<Float> original, class_1113 sound) {
        float result = original.call(instance, volume, category);
        String id = sound.method_4775().toString();
        float modifier = SoundConfig.getVolumeModifier(id);
        if (modifier > 1.0f) {
            return result * modifier;
        }
        return result;
    }
}
