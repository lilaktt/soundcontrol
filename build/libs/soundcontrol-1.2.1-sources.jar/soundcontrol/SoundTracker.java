package soundcontrol;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class SoundTracker {
    public static boolean showOverlay = false;
    private static final Map<String, Long> activeSounds = new LinkedHashMap<>();

    public static void recordSound(String soundId) {
        if (!showOverlay) return;
        if (SoundConfig.getVolumeModifier(soundId) <= 0.0f) return;

        synchronized (activeSounds) {
            activeSounds.remove(soundId);
            activeSounds.put(soundId, System.currentTimeMillis() + 3000);
        }
    }

    public static void render(class_332 context) {
        if (!showOverlay) return;

        class_310 client = class_310.method_1551();
        long currentTime = System.currentTimeMillis();
        int yOffset = 5;

        synchronized (activeSounds) {
            Iterator<Map.Entry<String, Long>> iterator = activeSounds.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, Long> entry = iterator.next();
                if (currentTime > entry.getValue()) {
                    iterator.remove();
                } else {
                    context.method_25303(client.field_1772, entry.getKey(), 5, yOffset, 0x00FF00);
                    yOffset += 10;
                }
            }
        }
    }
}