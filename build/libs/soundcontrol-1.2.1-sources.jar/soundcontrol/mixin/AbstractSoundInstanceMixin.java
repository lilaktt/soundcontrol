package soundcontrol.mixin;

import net.minecraft.class_1102;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import soundcontrol.SoundConfig;

@Mixin(class_1102.class)
public class AbstractSoundInstanceMixin {
    @Inject(method = "getVolume", at = @At("RETURN"), cancellable = true)
    private void modifyVolume(CallbackInfoReturnable<Float> cir) {
        String id = ((class_1102) (Object) this).method_4775().toString();
        float modifier = SoundConfig.getVolumeModifier(id);
        cir.setReturnValue(cir.getReturnValue() * modifier);
    }
}