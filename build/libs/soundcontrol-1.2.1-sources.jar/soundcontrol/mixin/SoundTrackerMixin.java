package soundcontrol.mixin;

import net.minecraft.class_1113;
import net.minecraft.class_1144;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import soundcontrol.SoundTracker;

@Mixin(class_1144.class)
public class SoundTrackerMixin {
    @Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;)V", at = @At("HEAD"))
    private void onPlaySound(class_1113 sound, CallbackInfo ci) {
        if (sound != null && sound.method_4775() != null) {

            SoundTracker.recordSound(sound.method_4775().toString());
        }
    }
}