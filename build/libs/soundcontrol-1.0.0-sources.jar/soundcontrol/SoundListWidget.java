package soundcontrol;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_7923;

public class SoundListWidget extends class_4265<SoundListWidget.SoundEntry> {
    private final List<SoundEntry> allEntries = new ArrayList<>();

    public SoundListWidget(class_310 client, int width, int height, int y, int itemHeight) {
        super(client, width, height, y, itemHeight);
        this.loadEntries(false);
    }

    public void loadEntries(boolean isAdvanced) {
        this.allEntries.clear();

        if (isAdvanced) {
            List<String> rawIds = new ArrayList<>();
            for (class_2960 id : class_7923.field_41172.method_10235()) {
                rawIds.add(id.toString());
            }
            Collections.sort(rawIds);
            for (String id : rawIds) {
                this.allEntries.add(new SoundEntry(id));
            }
        } else {
            Set<String> uniqueGroups = new HashSet<>();
            for (class_2960 id : class_7923.field_41172.method_10235()) {
                uniqueGroups.add(SoundConfig.getSoundGroup(id.toString()));
            }

            List<String> sortedGroups = new ArrayList<>(uniqueGroups);
            Collections.sort(sortedGroups);

            this.allEntries.add(new SoundEntry("#global:break"));
            this.allEntries.add(new SoundEntry("#global:place"));
            this.allEntries.add(new SoundEntry("#global:step"));
            this.allEntries.add(new SoundEntry("#global:hit"));
            this.allEntries.add(new SoundEntry("#global:hostile_hurt"));
            this.allEntries.add(new SoundEntry("#global:passive_hurt"));

            for (String group : sortedGroups) {
                this.allEntries.add(new SoundEntry(group));
            }
        }
    }

    @Override
    public int method_25322() {
        return 380;
    }

    @Override
    protected int method_25329() {
        return this.field_22758 / 2 + 195;
    }

    public void filter(String query, SoundCategory category) {
        this.method_25339();
        String lowerQuery = query.toLowerCase();
        for (SoundEntry entry : this.allEntries) {
            boolean matchCategory = false;

            if (category == SoundCategory.ALL) {
                matchCategory = true;
            } else if (category == SoundCategory.MOBS) {
                matchCategory = entry.soundId.startsWith("minecraft:entity.") || entry.soundId.contains("_hurt");
            } else if (category == SoundCategory.BLOCKS) {
                matchCategory = entry.soundId.startsWith("minecraft:block.");
            } else if (category == SoundCategory.MODS) {
                matchCategory = !entry.soundId.startsWith("minecraft:") && !entry.soundId.startsWith("#global:");
            }

            if (matchCategory && entry.soundId.toLowerCase().contains(lowerQuery)) {
                this.method_25321(entry);
            }
        }
        this.method_25307(0);
    }

    public static class SoundEntry extends class_4265.class_4266<SoundEntry> {
        final String soundId;
        private final class_4185 muteButton;
        private final class_357 volumeSlider;

        public SoundEntry(String soundId) {
            this.soundId = soundId;

            boolean initialMuted = false;
            float initialVolume = 1.0f;

            if (SoundConfig.SOUNDS.containsKey(soundId)) {
                initialMuted = SoundConfig.SOUNDS.get(soundId).muted;
                initialVolume = SoundConfig.SOUNDS.get(soundId).volume;
            }

            this.muteButton = class_4185.method_46430(class_2561.method_43470(initialMuted ? "Unmute" : "Mute"), button -> {
                SoundConfig.SoundSettings s = SoundConfig.SOUNDS.computeIfAbsent(this.soundId, k -> new SoundConfig.SoundSettings());
                s.muted = !s.muted;
                button.method_25355(class_2561.method_43470(s.muted ? "Unmute" : "Mute"));
                SoundConfig.save();
            }).method_46434(0, 0, 50, 20).method_46431();

            this.volumeSlider = new class_357(0, 0, 100, 20, class_2561.method_43470(String.format("Volume: %d%%", (int)(initialVolume * 100))), initialVolume / 2.0f) {
                @Override
                protected void method_25346() {
                    this.method_25355(class_2561.method_43470(String.format("Volume: %d%%", (int)(this.field_22753 * 200))));
                }

                @Override
                protected void method_25344() {
                    SoundConfig.SoundSettings s = SoundConfig.SOUNDS.computeIfAbsent(soundId, k -> new SoundConfig.SoundSettings());
                    s.volume = (float) (this.field_22753 * 2.0f);
                    SoundConfig.save();
                }
            };
        }

        @Override
        public void method_25343(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
            String displayId = this.soundId;
            if (displayId.equals("#global:break")) displayId = "ALL BREAKING SOUNDS";
            if (displayId.equals("#global:place")) displayId = "ALL PLACING SOUNDS";
            if (displayId.equals("#global:step")) displayId = "ALL FOOTSTEP SOUNDS";
            if (displayId.equals("#global:hit")) displayId = "ALL HIT SOUNDS";
            if (displayId.equals("#global:hostile_hurt")) displayId = "ALL HOSTILE MOB HURT SOUNDS";
            if (displayId.equals("#global:passive_hurt")) displayId = "ALL PASSIVE MOB HURT SOUNDS";

            String trimmedText = class_310.method_1551().field_1772.method_27523(displayId, entryWidth - 165);
            int color = this.soundId.startsWith("#global:") ? 0xFFAA00 : 0xFFFFFF;
            context.method_25303(class_310.method_1551().field_1772, trimmedText, x + 5, y + 6, color);

            this.muteButton.method_46421(x + entryWidth - 160);
            this.muteButton.method_46419(y);
            this.muteButton.method_25394(context, mouseX, mouseY, tickDelta);

            this.volumeSlider.method_46421(x + entryWidth - 105);
            this.volumeSlider.method_46419(y);
            this.volumeSlider.method_25394(context, mouseX, mouseY, tickDelta);
        }

        @Override
        public List<? extends net.minecraft.class_364> method_25396() {
            return List.of(this.muteButton, this.volumeSlider);
        }

        @Override
        public List<? extends net.minecraft.class_6379> method_37025() {
            return List.of(this.muteButton, this.volumeSlider);
        }
    }
}