package soundcontrol;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class SoundControl implements ClientModInitializer {
    public static class_304 openScreenKey;

    @Override
    public void onInitializeClient() {
        SoundConfig.load();

        openScreenKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.soundcontrol.open",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_V,
                "category.soundcontrol.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openScreenKey.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new SoundControlScreen());
                }
            }
        });
    }
}