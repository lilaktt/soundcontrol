package soundcontrol;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class SoundConfig {
    private static final File CONFIG_FILE = new File(FabricLoader.getInstance().getConfigDir().toFile(), "soundcontrol.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static Map<String, SoundSettings> SOUNDS = new HashMap<>();

    // Список базових ворожих мобів для фільтрації
    private static final Set<String> HOSTILE_MOBS = Set.of(
            "zombie", "creeper", "skeleton", "spider", "enderman", "witch", "slime", "ghast",
            "zombified_piglin", "piglin", "piglin_brute", "hoglin", "zoglin", "phantom",
            "silverfish", "endermite", "guardian", "elder_guardian", "shulker", "vindicator",
            "evoker", "pillager", "ravager", "vex", "illusioner", "warden", "wither",
            "ender_dragon", "stray", "husk", "drowned", "magma_cube", "blaze", "wither_skeleton",
            "bogged", "breeze"
    );

    public static class SoundSettings {
        public float volume = 1.0f;
        public boolean muted = false;
    }

    public static void load() {
        if (CONFIG_FILE.exists()) {
            try (FileReader reader = new FileReader(CONFIG_FILE)) {
                Type type = new TypeToken<Map<String, SoundSettings>>(){}.getType();
                SOUNDS = GSON.fromJson(reader, type);
                if (SOUNDS == null) SOUNDS = new HashMap<>();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void save() {
        try (FileWriter writer = new FileWriter(CONFIG_FILE)) {
            GSON.toJson(SOUNDS, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getSoundGroup(String soundId) {
        if (soundId.startsWith("minecraft:entity.")) {
            String[] parts = soundId.split("\\.");
            if (parts.length >= 2) {
                return "minecraft:entity." + parts[1];
            }
        }
        if (soundId.startsWith("minecraft:block.")) {
            String[] parts = soundId.split("\\.");
            if (parts.length >= 2) {
                return "minecraft:block." + parts[1];
            }
        }
        return soundId;
    }

    private static float getSettingsVolume(SoundSettings s) {
        return s.muted ? 0.0f : s.volume;
    }

    public static float getVolumeModifier(String id) {
        // 1. Найвищий пріоритет: Точний збіг (Advanced Mode)
        if (SOUNDS.containsKey(id)) {
            return getSettingsVolume(SOUNDS.get(id));
        }

        // 2. Пріоритет глобальних перемикачів (Basic Mode)
        if (id.contains(".break") && SOUNDS.containsKey("#global:break")) {
            return getSettingsVolume(SOUNDS.get("#global:break"));
        }
        if (id.contains(".place") && SOUNDS.containsKey("#global:place")) {
            return getSettingsVolume(SOUNDS.get("#global:place"));
        }
        if (id.contains(".step") && SOUNDS.containsKey("#global:step")) {
            return getSettingsVolume(SOUNDS.get("#global:step"));
        }
        if (id.contains(".hit") && SOUNDS.containsKey("#global:hit")) {
            return getSettingsVolume(SOUNDS.get("#global:hit"));
        }

        // Перевірка на отримання урону (Hurt) для мобів
        if (id.startsWith("minecraft:entity.") && id.contains(".hurt")) {
            String[] parts = id.split("\\.");
            if (parts.length >= 2) {
                String mobName = parts[1];
                if (HOSTILE_MOBS.contains(mobName) && SOUNDS.containsKey("#global:hostile_hurt")) {
                    return getSettingsVolume(SOUNDS.get("#global:hostile_hurt"));
                } else if (!HOSTILE_MOBS.contains(mobName) && SOUNDS.containsKey("#global:passive_hurt")) {
                    return getSettingsVolume(SOUNDS.get("#global:passive_hurt"));
                }
            }
        }

        // 3. Збіг по групі (minecraft:block.stone або minecraft:entity.zombie)
        String group = getSoundGroup(id);
        if (SOUNDS.containsKey(group)) {
            return getSettingsVolume(SOUNDS.get(group));
        }

        return 1.0f;
    }
}