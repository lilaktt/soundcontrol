package soundcontrol;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import org.lwjgl.glfw.GLFW;

public class SoundControlScreen extends class_437 {
    private class_342 searchBox;
    private SoundListWidget soundList;
    private SoundCategory currentCategory = SoundCategory.ALL;
    private boolean isAdvanced = false;

    public SoundControlScreen() {
        super(class_2561.method_43470("Sound Control"));
    }

    @Override
    protected void method_25426() {
        this.searchBox = new class_342(this.field_22793, this.field_22789 / 2 - 110, 22, 220, 20, class_2561.method_43470(""));
        this.searchBox.method_1863(this::onSearch);
        this.method_25429(this.searchBox);

        int buttonWidth = 60;
        int startX = this.field_22789 / 2 - (buttonWidth * 4 + 15) / 2;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("All"), b -> setCategory(SoundCategory.ALL)).method_46434(startX, 46, buttonWidth, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Mobs"), b -> setCategory(SoundCategory.MOBS)).method_46434(startX + buttonWidth + 5, 46, buttonWidth, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Blocks"), b -> setCategory(SoundCategory.BLOCKS)).method_46434(startX + (buttonWidth + 5) * 2, 46, buttonWidth, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Mods"), b -> setCategory(SoundCategory.MODS)).method_46434(startX + (buttonWidth + 5) * 3, 46, buttonWidth, 20).method_46431());

        this.soundList = new SoundListWidget(this.field_22787, this.field_22789, this.field_22790 - 116, 72, 25);
        this.method_25429(this.soundList);

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Mode: Basic"), button -> {
            this.isAdvanced = !this.isAdvanced;
            button.method_25355(class_2561.method_43470("Mode: " + (this.isAdvanced ? "Advanced" : "Basic")));
            this.soundList.loadEntries(this.isAdvanced);
            this.soundList.filter(this.searchBox.method_1882(), this.currentCategory);
        }).method_46434(this.field_22789 / 2 - 160, this.field_22790 - 28, 100, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_5244.field_24334, button -> this.method_25419())
                .method_46434(this.field_22789 / 2 - 50, this.field_22790 - 28, 100, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reset All"), button -> {
            SoundConfig.SOUNDS.clear();
            SoundConfig.save();
            this.soundList.loadEntries(this.isAdvanced);
            this.soundList.filter(this.searchBox.method_1882(), this.currentCategory);
        }).method_46434(this.field_22789 / 2 + 60, this.field_22790 - 28, 100, 20).method_46431());

        this.method_48265(this.searchBox);
        this.soundList.filter(this.searchBox.method_1882(), this.currentCategory);
    }

    private void setCategory(SoundCategory category) {
        this.currentCategory = category;
        this.soundList.filter(this.searchBox.method_1882(), this.currentCategory);
    }

    private void onSearch(String query) {
        if (this.soundList != null) {
            this.soundList.filter(query, this.currentCategory);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        this.soundList.method_25394(context, mouseX, mouseY, delta);
        this.searchBox.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 8, 0xFFFFFF);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE && this.method_25422()) {
            this.method_25419();
            return true;
        }
        if (this.searchBox.method_25404(keyCode, scanCode, modifiers) || this.searchBox.method_20315()) {
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}